#!/bin/sh
cd `dirname $0`
ROOT_PATH=`pwd`
java -Xms256M -Xmx1024M -cp .:$ROOT_PATH:$ROOT_PATH/../lib/routines.jar:$ROOT_PATH/../lib/log4j-1.2.16.jar:$ROOT_PATH/../lib/dom4j-1.6.1.jar:$ROOT_PATH/../lib/apache-httpcomponents-httpcore.jar:$ROOT_PATH/../lib/json-1.5-20090211.jar:$ROOT_PATH/../lib/apache-httpcomponents-httpclient.jar:$ROOT_PATH/../lib/postgresql-8.3-603.jdbc3.jar:$ROOT_PATH/../lib/httpclient-4.0.2.jar:$ROOT_PATH/contentmigrationpsql_0_1.jar: learning.contentmigrationpsql_0_1.ContentMigrationPSQL --context=Default "$@" 